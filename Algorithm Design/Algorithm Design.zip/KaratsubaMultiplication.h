
#ifndef KARATSUBAMULTIPLICATION_H_
#define KARATSUBAMULTIPLICATION_H_

int getLength(long long value);
long long multiply(long long x, long long y);



#endif
